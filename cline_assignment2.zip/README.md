# MachineLearning-Assignment-02
Repo for second machine learning assignment. Uses Logistic regression on the same data set as assignment 1.
